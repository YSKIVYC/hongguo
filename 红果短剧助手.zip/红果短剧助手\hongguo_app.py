#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
红果短剧助手 - 独立版
功能：粘贴分享链接 → 在线播放（免广告）/ 批量下载完整正片
纯 Python 标准库，无第三方依赖。
"""
import json
import os
import socket
import sys
import threading
import time
import urllib.parse
import urllib.request
import urllib.error
import webbrowser
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

# PyInstaller 打包后取 exe 所在目录，开发时取脚本目录
if getattr(sys, "frozen", False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import hongguo_dl

PORT = 18090
HOST = "127.0.0.1"

DOWN_DIR = os.path.join(BASE_DIR, "短剧下载")

# ======================== 在线播放直链缓存 ========================
_URL_CACHE = {}
_URL_TTL = 600


def stream_url(series_id, episode_id, force=False):
    key = (series_id, episode_id)
    if not force:
        cached = _URL_CACHE.get(key)
        if cached and time.time() - cached[1] < _URL_TTL:
            return cached[0]
    url = hongguo_dl.get_episode_info(series_id, episode_id)
    _URL_CACHE[key] = (url, time.time())
    return url


# ======================== 下载任务管理 ========================
class Task:
    def __init__(self):
        self.running = False
        self.stop_flag = False
        self.progress = 0.0
        self.speed = ""
        self.status = "idle"  # idle / running / success / error
        self.logs = []

    def log(self, msg):
        self.logs.append(msg)
        if len(self.logs) > 300:
            self.logs = self.logs[-300:]


task = Task()


def download_worker(url, ep_nums, out_dir, log, progress, speed, should_stop):
    info = hongguo_dl.parse_input(url)
    series = hongguo_dl.get_series_info(info["series_id"])
    if not series["vid_list"]:
        series["vid_list"] = info.get("chapter_ids", [])

    picked = [i for i in range(len(series["vid_list"])) if (i + 1) in ep_nums]
    if not picked:
        raise RuntimeError("没有选中任何集数")

    log("短剧: %s，共 %d 集，本次下载 %d 集" % (series["title"], series["total"], len(picked)))

    final_dir = os.path.join(out_dir, series["title"])
    os.makedirs(final_dir, exist_ok=True)

    ok = fail = 0
    for n, idx in enumerate(picked):
        if should_stop():
            break
        vid = series["vid_list"][idx]
        ep_num = idx + 1
        save_path = os.path.join(final_dir, "第%02d集.mp4" % ep_num)
        log("[%d/%d] 第%02d集 ..." % (n + 1, len(picked), ep_num))
        try:
            if os.path.exists(save_path):
                log("  已存在，跳过")
                ok += 1
                progress((n + 1) * 100.0 / len(picked))
                continue
            video_url = stream_url(series["series_id"], vid)
            base_pct = n * 100.0 / len(picked)
            seg = 100.0 / len(picked)
            start_t = time.time()

            def cb(done, total, speed_str, _b=base_pct, _s=seg, _t0=start_t):
                pct = _b + (done / total * _s if total else 0)
                progress(pct)
                elapsed = max(time.time() - _t0, 0.001)
                speed("%.1f MB/s" % (done / 1048576 / elapsed))

            hongguo_dl.download_file(video_url, save_path, progress_cb=cb)
            log("  已保存: %s" % save_path)
            ok += 1
        except Exception as e:
            log("  失败: %s" % e)
            fail += 1

    log("完成: 成功 %d，失败 %d，目录: %s" % (ok, fail, final_dir))
    if should_stop():
        raise RuntimeError("已停止")


# ======================== 前端页面 ========================
HTML_PAGE = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>红果短剧助手</title>
<style>
:root {
    --bg: #0f0f1a; --surface: #1a1a2e; --surface-light: #24243e;
    --border: #2d2d4a; --text: #e8e8f0; --text-dim: #8888a8; --text-muted: #b0b0c8;
    --primary: #6366f1; --secondary: #8b5cf6; --success: #10b981;
    --warning: #f59e0b; --danger: #ef4444;
    --radius: 14px; --radius-sm: 8px; --mono: 'Consolas', monospace;
}
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: -apple-system, 'Segoe UI', 'Microsoft YaHei', sans-serif; background: var(--bg); color: var(--text); min-height: 100vh; }
.container { max-width: 1080px; margin: 0 auto; padding: 28px 20px 60px; }
.header { text-align: center; margin-bottom: 28px; }
.header h1 { font-size: 1.7rem; background: linear-gradient(90deg, var(--primary), var(--secondary)); -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent; }
.header p { color: var(--text-dim); font-size: .9rem; margin-top: 6px; }
.card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 22px; margin-bottom: 18px; }
.card-title { font-weight: 700; font-size: 1.05rem; margin-bottom: 16px; }
.form-row { margin-bottom: 14px; }
.form-label { display: block; font-size: .85rem; color: var(--text-muted); margin-bottom: 7px; }
.form-input { width: 100%; padding: 10px 13px; background: var(--surface-light); border: 1px solid var(--border); border-radius: var(--radius-sm); color: var(--text); font-size: .9rem; outline: none; transition: border-color .2s; }
.form-input:focus { border-color: var(--primary); }
.form-input::placeholder { color: var(--text-dim); }
.url-wrap { display: flex; gap: 8px; }
.url-wrap .form-input { flex: 1; }
.btn { padding: 10px 22px; border: none; border-radius: var(--radius-sm); font-size: .92rem; font-weight: 600; cursor: pointer; transition: all .2s; }
.btn-primary { background: linear-gradient(135deg, var(--primary), var(--secondary)); color: #fff; }
.btn-primary:hover { transform: translateY(-1px); box-shadow: 0 4px 14px rgba(99,102,241,.4); }
.btn-secondary { background: var(--surface-light); color: var(--text); border: 1px solid var(--border); }
.btn-secondary:hover { border-color: var(--primary); }
.btn-sm { padding: 7px 14px; font-size: .82rem; }
.btn:disabled { opacity: .5; cursor: not-allowed; transform: none; }
.actions { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
#hg_info { color: var(--text-dim); font-size: .85rem; }
.hg-eps { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 8px; margin: 10px 0 14px; }
.hg-ep { display: flex; align-items: center; justify-content: space-between; gap: 6px; background: var(--surface-light); border: 1px solid var(--border); border-radius: var(--radius-sm); padding: 6px 8px 6px 10px; }
.hg-ep label { display: flex; align-items: center; gap: 7px; cursor: pointer; flex: 1; min-width: 0; font-size: .85rem; }
.hg-ep.playing { border-color: var(--primary); background: rgba(99,102,241,0.15); }
.hg-play-btn { flex-shrink: 0; width: 30px; height: 30px; border-radius: 50%; border: none; background: var(--primary); color: #fff; cursor: pointer; font-size: 11px; display: flex; align-items: center; justify-content: center; padding: 0; }
.hg-play-btn:hover { background: var(--secondary); }
.section-label { font-size: .85rem; color: var(--text-muted); margin-bottom: 8px; }
.file-row { display: flex; gap: 8px; }
.file-row .form-input { flex: 1; }
.hint { font-size: .8rem; color: var(--text-dim); line-height: 1.7; margin-top: 14px; padding-top: 12px; border-top: 1px dashed var(--border); }
.progress-bar { width: 100%; height: 20px; background: var(--surface-light); border: 1px solid var(--border); border-radius: 10px; overflow: hidden; }
.progress-fill { height: 100%; width: 0%; background: linear-gradient(90deg, var(--primary), var(--secondary)); border-radius: 10px; transition: width .3s ease; }
.progress-info { display: flex; justify-content: space-between; margin-top: 7px; font-size: 13px; }
.progress-speed { color: var(--secondary); font-family: var(--mono); }
.console { background: #0a0a14; border: 1px solid var(--border); border-radius: var(--radius-sm); height: 220px; overflow-y: auto; padding: 12px; font-family: var(--mono); font-size: 12.5px; line-height: 1.6; white-space: pre-wrap; word-break: break-all; margin-top: 14px; }
.toast-container { position: fixed; top: 20px; right: 20px; z-index: 9999; display: flex; flex-direction: column; gap: 8px; }
.toast { padding: 12px 20px; border-radius: var(--radius-sm); font-size: 14px; color: white; box-shadow: 0 8px 24px rgba(0,0,0,.4); animation: slideIn .3s ease; }
.toast.success { background: var(--success); color: #0a0a0a; }
.toast.error { background: var(--danger); }
.toast.warning { background: var(--warning); color: #0a0a0a; }
@keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: none; opacity: 1; } }
.player-overlay { display: none; position: fixed; inset: 0; z-index: 9998; background: rgba(0,0,0,0.82); backdrop-filter: blur(4px); }
.player-overlay.show { display: flex; align-items: center; justify-content: center; }
.player-box { width: min(920px, 94vw); background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); overflow: hidden; }
.player-head { display: flex; justify-content: space-between; align-items: center; gap: 10px; padding: 10px 16px; border-bottom: 1px solid var(--border); }
.player-title { font-weight: 700; font-size: .95rem; }
.player-actions { display: flex; gap: 8px; align-items: center; }
.player-close { width: 32px; height: 32px; border: none; border-radius: var(--radius-sm); background: var(--surface-light); color: var(--text); font-size: 15px; cursor: pointer; }
.player-close:hover { background: var(--danger); color: #fff; }
.player-box video { display: block; width: 100%; max-height: 70vh; background: #000; }
.player-foot { display: flex; justify-content: flex-end; align-items: center; padding: 8px 16px; border-top: 1px solid var(--border); font-size: .85rem; }
.player-autonext { display: flex; align-items: center; gap: 6px; cursor: pointer; color: var(--text-muted); }
</style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>🎭 红果短剧助手</h1>
        <p>粘贴分享链接，在线免广告看剧，或批量下载完整正片</p>
    </div>

    <div class="card">
        <div class="card-title">解析短剧</div>
        <div class="form-row">
            <label class="form-label">分享链接 / 播放页链接</label>
            <div class="url-wrap">
                <input type="text" class="form-input" id="hg_url" placeholder="粘贴红果短剧分享链接（微信/QQ转发的 novelquickapp.com 链接）">
                <button class="btn btn-secondary btn-sm" onclick="pasteTo()">粘贴</button>
            </div>
        </div>
        <div class="actions">
            <button class="btn btn-primary" id="parse_btn" onclick="parseHongguo()">解析剧集</button>
            <span id="hg_info"></span>
        </div>
    </div>

    <div class="card" id="eps_card" style="display:none">
        <div class="card-title">剧集列表 <span id="eps_count" style="font-size:.8rem;color:var(--text-dim);font-weight:400"></span></div>
        <div class="section-label">点 ▶ 在线播放（免广告）；勾选后可批量下载</div>
        <div class="actions" style="margin-bottom:6px">
            <button class="btn btn-secondary btn-sm" onclick="hgToggleAll(true)">全选</button>
            <button class="btn btn-secondary btn-sm" onclick="hgToggleAll(false)">全不选</button>
        </div>
        <div class="hg-eps" id="hg_episodes"></div>
        <div class="form-row">
            <label class="form-label">保存目录</label>
            <div class="file-row">
                <input type="text" class="form-input" id="hg_out" placeholder="默认: exe旁边的 短剧下载 文件夹">
            </div>
        </div>
        <div class="actions">
            <button class="btn btn-primary" id="start_btn" onclick="startDownload()">开始下载</button>
            <button class="btn btn-secondary" id="stop_btn" onclick="stopDownload()" style="display:none">停止</button>
        </div>
        <div style="margin-top:16px">
            <div class="progress-bar"><div class="progress-fill" id="progFill"></div></div>
            <div class="progress-info">
                <span id="progPct">0%</span>
                <span class="progress-speed" id="progSpeed"></span>
            </div>
        </div>
        <div class="console" id="consoleBox">等待任务…</div>
        <div class="hint">
            支持红果短剧分享链接（微信/QQ转发的 novelquickapp.com 链接）或网页版播放页链接。<br>
            在线播放走本地代理流式加载，支持拖进度条、自动连播；下载的是 720P 完整正片，已下载自动跳过。
        </div>
    </div>
</div>

<div class="player-overlay" id="playerOverlay" onclick="if(event.target===this)closePlayer()">
    <div class="player-box">
        <div class="player-head">
            <span class="player-title" id="playerTitle">在线播放</span>
            <div class="player-actions">
                <button class="btn btn-secondary btn-sm" onclick="hgPlayShift(-1)">上一集</button>
                <button class="btn btn-secondary btn-sm" onclick="hgPlayShift(1)">下一集</button>
                <button class="player-close" onclick="closePlayer()" title="关闭 (Esc)">✕</button>
            </div>
        </div>
        <video id="playerVideo" controls autoplay playsinline></video>
        <div class="player-foot">
            <label class="player-autonext"><input type="checkbox" id="autoNext" checked> 播完自动连播下一集</label>
        </div>
    </div>
</div>

<div class="toast-container" id="toastContainer"></div>

<script>
let HG_DATA = null;
let HG_PLAYING = null;
let polling = null;

function showToast(msg, type) {
    const t = document.createElement('div');
    t.className = 'toast ' + type;
    t.textContent = msg;
    document.getElementById('toastContainer').appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'all .3s'; setTimeout(() => t.remove(), 300); }, 3000);
}

async function pasteTo() {
    try {
        const text = await navigator.clipboard.readText();
        if (text) document.getElementById('hg_url').value = text.trim();
    } catch (e) { showToast('浏览器不允许自动粘贴，请 Ctrl+V', 'warning'); }
}

async function parseHongguo() {
    const url = document.getElementById('hg_url').value.trim();
    if (!url) { showToast('请先粘贴分享链接', 'warning'); return; }
    const btn = document.getElementById('parse_btn');
    const info = document.getElementById('hg_info');
    btn.disabled = true; btn.textContent = '解析中…';
    info.textContent = '';
    try {
        const resp = await fetch('/api/parse', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ url })
        });
        const r = await resp.json();
        if (!r.success) { showToast(r.message, 'error'); return; }
        HG_DATA = r.data;
        info.textContent = '《' + r.data.title + '》共 ' + r.data.total + ' 集';
        document.getElementById('eps_count').textContent = '（共 ' + r.data.total + ' 集）';
        renderEps();
        document.getElementById('eps_card').style.display = 'block';
        showToast('解析成功: 《' + r.data.title + '》' + r.data.total + ' 集', 'success');
    } catch (e) {
        showToast('解析失败: ' + e.message, 'error');
    } finally {
        btn.disabled = false; btn.textContent = '解析剧集';
    }
}

function renderEps() {
    const wrap = document.getElementById('hg_episodes');
    let html = '';
    HG_DATA.episodes.forEach(ep => {
        html += '<div class="hg-ep" id="hg-ep-' + ep.num + '">'
            + '<label><input type="checkbox" value="' + ep.num + '" checked>'
            + '<span>第' + String(ep.num).padStart(2, '0') + '集</span></label>'
            + '<button class="hg-play-btn" title="在线播放" onclick="playEp(' + ep.num + ')">▶</button>'
            + '</div>';
    });
    wrap.innerHTML = html;
}

function hgToggleAll(checked) {
    document.querySelectorAll('#hg_episodes input[type=checkbox]').forEach(cb => cb.checked = checked);
}

function playEp(num) {
    if (!HG_DATA) return;
    const ep = HG_DATA.episodes.find(e => e.num === num);
    if (!ep) return;
    HG_PLAYING = num;
    const v = document.getElementById('playerVideo');
    v.src = '/api/stream?series=' + HG_DATA.series_id + '&ep=' + ep.vid;
    v.play().catch(() => {});
    document.getElementById('playerTitle').textContent = '《' + HG_DATA.title + '》第' + String(num).padStart(2, '0') + '集';
    document.getElementById('playerOverlay').classList.add('show');
    document.querySelectorAll('.hg-ep').forEach(el => el.classList.remove('playing'));
    const cur = document.getElementById('hg-ep-' + num);
    if (cur) cur.classList.add('playing');
}

function hgPlayShift(delta) {
    if (!HG_DATA || !HG_PLAYING) return;
    const next = HG_PLAYING + delta;
    if (next < 1 || next > HG_DATA.total) {
        showToast(delta > 0 ? '已经是最后一集了' : '已经是第一集了', 'warning');
        return;
    }
    playEp(next);
}

function closePlayer() {
    const v = document.getElementById('playerVideo');
    v.pause(); v.removeAttribute('src'); v.load();
    document.getElementById('playerOverlay').classList.remove('show');
    HG_PLAYING = null;
    document.querySelectorAll('.hg-ep').forEach(el => el.classList.remove('playing'));
}

document.getElementById('playerVideo').addEventListener('ended', () => {
    if (document.getElementById('autoNext').checked && HG_PLAYING && HG_DATA && HG_PLAYING < HG_DATA.total) {
        playEp(HG_PLAYING + 1);
    }
});
document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && document.getElementById('playerOverlay').classList.contains('show')) closePlayer();
});

async function startDownload() {
    const url = document.getElementById('hg_url').value.trim();
    const outDir = document.getElementById('hg_out').value.trim();
    const checked = Array.from(document.querySelectorAll('#hg_episodes input[type=checkbox]:checked')).map(cb => parseInt(cb.value));
    if (!url) { showToast('请先粘贴分享链接', 'warning'); return; }
    if (!HG_DATA) { showToast('请先点击「解析剧集」', 'warning'); return; }
    if (!checked.length) { showToast('请至少勾选一集', 'warning'); return; }
    try {
        const resp = await fetch('/api/start', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ url, episodes: checked, out_dir: outDir })
        });
        const r = await resp.json();
        if (!r.success) { showToast(r.message, 'error'); return; }
        showToast('开始下载 ' + checked.length + ' 集', 'success');
        document.getElementById('start_btn').disabled = true;
        document.getElementById('stop_btn').style.display = '';
        startPolling();
    } catch (e) { showToast('启动失败: ' + e.message, 'error'); }
}

async function stopDownload() {
    try { await fetch('/api/stop', { method: 'POST' }); } catch (e) {}
}

function startPolling() {
    if (polling) clearInterval(polling);
    polling = setInterval(async () => {
        try {
            const r = await (await fetch('/api/status')).json();
            document.getElementById('progFill').style.width = (r.progress || 0) + '%';
            document.getElementById('progPct').textContent = (r.progress || 0).toFixed(1) + '%';
            document.getElementById('progSpeed').textContent = r.speed || '';
            const box = document.getElementById('consoleBox');
            const text = (r.logs || []).join('\\n');
            if (text !== box.textContent) { box.textContent = text || '等待任务…'; box.scrollTop = box.scrollHeight; }
            if (!r.running) {
                clearInterval(polling); polling = null;
                document.getElementById('start_btn').disabled = false;
                document.getElementById('stop_btn').style.display = 'none';
                if (r.status === 'success') showToast('下载完成！', 'success');
                else if (r.status === 'error') showToast('任务出错，看日志', 'error');
            }
        } catch (e) {}
    }, 800);
}
</script>
</body>
</html>
"""


# ======================== HTTP 服务 ========================
class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    # ---------- GET ----------
    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        query = dict(urllib.parse.parse_qsl(parsed.query))
        if parsed.path in ("/", "/index.html"):
            self._send_html(HTML_PAGE)
        elif parsed.path == "/api/status":
            self._send_json({
                "running": task.running,
                "progress": task.progress,
                "speed": task.speed,
                "status": task.status,
                "logs": task.logs,
            })
        elif parsed.path == "/api/stream":
            self._serve_stream(query.get("series", ""), query.get("ep", ""))
        else:
            self.send_response(404)
            self.end_headers()

    # ---------- POST ----------
    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length).decode("utf-8", "utf-8") if length else "{}"
        try:
            data = json.loads(body) if body.strip() else {}
        except json.JSONDecodeError:
            data = {}

        if self.path == "/api/parse":
            url = (data.get("url") or "").strip()
            if not url:
                self._send_json({"success": False, "message": "请粘贴分享链接"})
                return
            try:
                info = hongguo_dl.parse_input(url)
                series = hongguo_dl.get_series_info(info["series_id"])
                if not series["vid_list"]:
                    series["vid_list"] = info.get("chapter_ids", [])
                    series["total"] = len(series["vid_list"])
                if not series["vid_list"]:
                    raise RuntimeError("未获取到剧集列表")
                self._send_json({
                    "success": True,
                    "data": {
                        "series_id": series["series_id"],
                        "title": series["title"],
                        "total": series["total"],
                        "episodes": [{"num": i + 1, "vid": v} for i, v in enumerate(series["vid_list"])],
                    },
                })
            except Exception as e:
                self._send_json({"success": False, "message": "解析失败: %s" % e})

        elif self.path == "/api/start":
            if task.running:
                self._send_json({"success": False, "message": "已有任务在运行"})
                return
            url = (data.get("url") or "").strip()
            eps = data.get("episodes") or []
            out_dir = (data.get("out_dir") or "").strip() or DOWN_DIR
            if not url or not eps:
                self._send_json({"success": False, "message": "参数不完整"})
                return
            task.running = True
            task.stop_flag = False
            task.progress = 0.0
            task.speed = ""
            task.status = "running"
            task.logs = []

            def run():
                try:
                    download_worker(
                        url, set(eps), out_dir,
                        lambda m: (task.log(m),),
                        lambda p: setattr(task, "progress", p),
                        lambda s: setattr(task, "speed", s),
                        lambda: task.stop_flag,
                    )
                    task.status = "success"
                except Exception as e:
                    task.log("错误: %s" % e)
                    task.status = "error"
                finally:
                    task.running = False

            threading.Thread(target=run, daemon=True).start()
            self._send_json({"success": True, "message": "ok"})

        elif self.path == "/api/stop":
            task.stop_flag = True
            self._send_json({"success": True})

        else:
            self.send_response(404)
            self.end_headers()

    # ---------- 流式代理 ----------
    def _serve_stream(self, series_id, episode_id):
        if not series_id or not episode_id:
            self.send_response(400)
            self.end_headers()
            return
        rng = self.headers.get("Range")
        last_err = "未知错误"
        for attempt in (0, 1):
            resp = None
            try:
                video_url = stream_url(series_id, episode_id, force=(attempt == 1))
                headers = {"User-Agent": hongguo_dl.UA, "Referer": hongguo_dl.WEB_BASE}
                if rng:
                    headers["Range"] = rng
                resp = urllib.request.urlopen(
                    urllib.request.Request(video_url, headers=headers), timeout=30)
                self.send_response(resp.status)
                for h in ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges"):
                    v = resp.headers.get(h)
                    if v:
                        self.send_header(h, v)
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                try:
                    while True:
                        chunk = resp.read(1024 * 256)
                        if not chunk:
                            break
                        self.wfile.write(chunk)
                except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                    pass
                return
            except urllib.error.HTTPError as e:
                last_err = "视频源返回 %d" % e.code
                if e.code in (403, 410) and attempt == 0:
                    continue
                break
            except Exception as e:
                last_err = str(e)
                break
            finally:
                if resp is not None:
                    try:
                        resp.close()
                    except Exception:
                        pass
        try:
            body = ("播放失败: %s" % last_err).encode("utf-8")
            self.send_response(502)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except Exception:
            pass

    # ---------- 工具 ----------
    def _send_json(self, obj):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _send_html(self, content):
        data = content.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


def main():
    url = f"http://{HOST}:{PORT}"

    def port_open():
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.5)
            return s.connect_ex((HOST, PORT)) == 0

    if port_open():
        print("红果短剧助手已在运行，直接打开浏览器…")
        webbrowser.open(url)
        return

    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print("=" * 40)
    print("  红果短剧助手 已启动!")
    print("  访问地址: %s" % url)
    print("  下载目录: %s" % DOWN_DIR)
    print("  关闭此窗口即退出程序")
    print("=" * 40)
    threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
