# -*- coding: utf-8 -*-
"""
红果短剧下载器 hongguo_dl.py
纯 Python 标准库实现，无第三方依赖。

原理：
  1. 分享链接(novelquickapp.com) -> 解析出 series_id（分享参数里的 video_id）
  2. 网页版播放页(hongguoduanju.com/player/{series_id}) -> SSR HTML 里含 vid_list（全部集数ID）
  3. 每集播放页(/player/{series_id}/{episode_id}) -> <video src> 标签里的完整 MP4 直链
  4. 支持 Range 断点续传下载

用法：
  python hongguo_dl.py <分享链接或播放页链接或series_id> [--out 输出目录] [--eps 1-5,8] [--list]
"""
import gzip
import html as html_mod
import json
import os
import re
import sys
import time
import urllib.request
import urllib.parse

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
WEB_BASE = 'https://www.hongguoduanju.com'


def http_get(url, referer=WEB_BASE, timeout=20):
    req = urllib.request.Request(url, headers={
        'User-Agent': UA,
        'Referer': referer,
        'Accept': 'text/html,application/json,*/*',
    })
    resp = urllib.request.urlopen(req, timeout=timeout)
    body = resp.read()
    if resp.headers.get('Content-Encoding') == 'gzip':
        body = gzip.decompress(body)
    return resp, body


def safe_filename(name):
    return re.sub(r'[\\/:*?"<>|\r\n\t]', '_', name).strip()[:80]


# ---------------------------------------------------------------- 链接解析

def parse_input(text):
    """识别输入：分享链接 / 播放页链接 / 详情页链接 / 纯 series_id"""
    text = text.strip()
    if re.fullmatch(r'\d{15,25}', text):
        return {'type': 'series_id', 'series_id': text}

    if 'novelquickapp.com' in text:
        try:
            _, body = http_get(text, referer='https://novelquickapp.com/')
            html_text = body.decode('utf-8', errors='replace')
        except Exception as e:
            raise RuntimeError('分享页请求失败: %s' % e)
        m = re.search(r'window\._ROUTER_DATA\s*=\s*(\{.*)</script>', html_text, re.S)
        if not m:
            raise RuntimeError('分享页数据解析失败')
        data = json.loads(m.group(1).rstrip().rstrip(';'))
        loader = data.get('loaderData', {})
        page = loader.get('video-animation-share_page', {})
        page_data = page.get('pageData', {})
        scheme = page.get('linkParams', {}).get('schemeParams', {})
        series_id = scheme.get('video_id') or ''
        title = page_data.get('series_data', {}).get('title') or '未知短剧'
        chapters = page_data.get('chapter_ids', [])
        if not series_id:
            raise RuntimeError('分享链接里没有找到 series_id')
        return {'type': 'share', 'series_id': series_id, 'title': title,
                'chapter_ids': chapters, 'share_url': text}

    m = re.search(r'hongguoduanju\.com/player/(\d+)(?:/(\d+))?', text)
    if m:
        return {'type': 'player', 'series_id': m.group(1), 'episode_id': m.group(2)}

    m = re.search(r'hongguoduanju\.com/detail\?series_id=(\d+)', text)
    if m:
        return {'type': 'detail', 'series_id': m.group(1)}

    raise RuntimeError('无法识别的链接，请粘贴红果分享链接或网页版播放页链接')


def search_drama(keyword, limit=20):
    """网页版搜索，返回 [{series_id, title, cover}]"""
    url = WEB_BASE + '/search/' + urllib.parse.quote(keyword)
    _, body = http_get(url)
    text = body.decode('utf-8', errors='replace')
    results = []
    seen = set()
    # 搜索结果卡：<a href="/detail?series_id=xxx" ...> 标题在附近
    for m in re.finditer(r'href="/detail\?series_id=(\d+)"', text):
        sid = m.group(1)
        if sid in seen:
            continue
        seen.add(sid)
        # 找卡片标题（alt 或附近文本）
        ctx = text[m.start():m.start() + 1500]
        tm = re.search(r'alt="([^"]+)"', ctx) or re.search(r'title="([^"]+)"', ctx)
        results.append({'series_id': sid, 'title': tm.group(1) if tm else sid})
        if len(results) >= limit:
            break
    return results


# ---------------------------------------------------------------- 剧集信息

def get_series_info(series_id):
    """从播放页 SSR 拿剧名 + 全部集数 ID 列表"""
    url = '%s/player/%s' % (WEB_BASE, series_id)
    _, body = http_get(url)
    text = body.decode('utf-8', errors='replace')

    tm = re.search(r'<title[^>]*>(.*?)</title>', text, re.S)
    title = tm.group(1).strip() if tm else series_id
    title = title.split('|')[0].strip()
    title = re.sub(r'第\s*\d+\s*集\s*$', '', title).strip() or series_id

    # 当前剧集的 vid_list（页面里第一个 vid_list 属于当前剧，后面是推荐剧的）
    vm = re.search(r'"vid_list":\s*(\["\d{15,25}"(?:,"\d{15,25}")*\])', text)
    vid_list = json.loads(vm.group(1)) if vm else []

    em = re.search(r'"episode_total_cnt":\s*(\d+)', text)
    total = int(em.group(1)) if em else len(vid_list)

    return {'series_id': series_id, 'title': safe_filename(title),
            'vid_list': vid_list, 'total': total}


def get_episode_info(series_id, episode_id):
    """请求某集播放页，返回视频直链"""
    url = '%s/player/%s/%s' % (WEB_BASE, series_id, episode_id)
    _, body = http_get(url)
    text = body.decode('utf-8', errors='replace')
    vm = re.search(r'<video[^>]*\ssrc="([^"]+)"', text)
    if not vm:
        vm = re.search(r'<video[^>]*\ssrc=\'([^\']+)\'', text)
    if not vm:
        # 兜底：找 qznovelvod 直链
        vm2 = re.search(r'(https?://v\d+-hgweb\.qznovelvod\.com/[^"\'<>\s]+)', text)
        if vm2:
            return html_mod.unescape(vm2.group(1))
        raise RuntimeError('第 %s 集视频地址未找到（可能需要登录或已下架）' % episode_id)
    return html_mod.unescape(vm.group(1))


# ---------------------------------------------------------------- 下载

def download_file(url, save_path, referer=WEB_BASE, progress_cb=None):
    """带进度回调的下载，支持断点续传。progress_cb(done, total, speed_str)"""
    tmp_path = save_path + '.part'
    downloaded = 0
    total = 0

    if os.path.exists(tmp_path):
        downloaded = os.path.getsize(tmp_path)

    headers = {'User-Agent': UA, 'Referer': referer}
    if downloaded > 0:
        headers['Range'] = 'bytes=%d-' % downloaded

    req = urllib.request.Request(url, headers=headers)
    resp = urllib.request.urlopen(req, timeout=30)
    cr = resp.headers.get('Content-Range')
    if cr:
        total = int(cr.rsplit('/', 1)[-1])
    else:
        cl = resp.headers.get('Content-Length')
        total = int(cl) if cl else 0
        if downloaded > 0 and total:
            total += downloaded

    if downloaded > 0 and total and downloaded >= total:
        os.replace(tmp_path, save_path)
        if progress_cb:
            progress_cb(total, total, '已完成')
        return True

    start_time = time.time()
    last_report = 0
    mode = 'ab' if downloaded > 0 else 'wb'
    with open(tmp_path, mode) as f:
        while True:
            chunk = resp.read(1024 * 256)
            if not chunk:
                break
            f.write(chunk)
            downloaded += len(chunk)
            now = time.time()
            if progress_cb and (now - last_report >= 0.3 or downloaded >= total):
                speed = downloaded / max(now - start_time, 0.001) / 1024
                progress_cb(downloaded, total, '%.1f MB/s' % speed)
                last_report = now

    if total and downloaded < total:
        raise RuntimeError('下载中断：%d/%d' % (downloaded, total))
    os.replace(tmp_path, save_path)
    if progress_cb:
        progress_cb(total, total, '完成')
    return True


# ---------------------------------------------------------------- CLI

def parse_eps_arg(arg, total):
    """解析 '1-5,8' 形式的集数选择，返回下标列表（0-based）"""
    if not arg or arg == 'all':
        return list(range(total))
    picked = set()
    for part in arg.split(','):
        part = part.strip()
        if '-' in part:
            a, b = part.split('-')
            for i in range(int(a) - 1, min(int(b), total)):
                picked.add(i)
        elif part.isdigit():
            i = int(part) - 1
            if 0 <= i < total:
                picked.add(i)
    return sorted(picked)


def main():
    args = sys.argv[1:]
    if not args or args[0] in ('-h', '--help'):
        print(__doc__)
        print('示例:')
        print('  python hongguo_dl.py "https://novelquickapp.com/hongguo/ug/pages/..."')
        print('  python hongguo_dl.py "https://www.hongguoduanju.com/player/7638987534483082265"')
        print('  python hongguo_dl.py 7638987534483082265 --eps 1-3')
        print('  python hongguo_dl.py --search 归墟')
        return

    if args[0] == '--search':
        kw = args[1] if len(args) > 1 else ''
        for r in search_drama(kw):
            print('%s  %s' % (r['series_id'], r['title']))
        return

    target = args[0]
    out_dir = '.'
    eps_arg = 'all'
    list_only = False
    i = 1
    while i < len(args):
        if args[i] == '--out':
            out_dir = args[i + 1]
            i += 2
        elif args[i] == '--eps':
            eps_arg = args[i + 1]
            i += 2
        elif args[i] == '--list':
            list_only = True
            i += 1
        else:
            i += 1

    info = parse_input(target)
    print('已识别: %s (series_id=%s)' % (info['type'], info['series_id']))

    series = get_series_info(info['series_id'])
    print('短剧: %s  共 %d 集' % (series['title'], series['total']))
    if not series['vid_list']:
        # 用分享页的 chapter_ids 兜底
        series['vid_list'] = info.get('chapter_ids', [])
        series['total'] = len(series['vid_list'])
        print('从分享页补充集数列表: %d 集' % series['total'])

    if list_only:
        for idx, vid in enumerate(series['vid_list'], 1):
            print('  第%02d集  %s' % (idx, vid))
        return

    picked = parse_eps_arg(eps_arg, series['total'])
    if not picked:
        print('没有选中任何集数')
        return
    print('将下载 %d 集: %s' % (len(picked), ','.join(str(i + 1) for i in picked)))

    os.makedirs(out_dir, exist_ok=True)
    out_dir = os.path.join(out_dir, series['title'])
    os.makedirs(out_dir, exist_ok=True)

    ok = fail = 0
    for n, idx in enumerate(picked, 1):
        vid = series['vid_list'][idx]
        ep_num = idx + 1
        save_path = os.path.join(out_dir, '第%02d集.mp4' % ep_num)
        print('\n[%d/%d] 第%02d集 ...' % (n, len(picked), ep_num))
        try:
            if os.path.exists(save_path):
                print('  已存在，跳过')
                ok += 1
                continue
            video_url = get_episode_info(series['series_id'], vid)

            def cb(done, total, speed):
                pct = (done * 100.0 / total) if total else 0
                sys.stdout.write('\r  %.1f%%  %.1f/%.1f MB  %s    ' % (
                    pct, done / 1048576, (total or 0) / 1048576, speed))
                sys.stdout.flush()

            download_file(video_url, save_path, progress_cb=cb)
            print('\n  保存至 %s' % save_path)
            ok += 1
        except Exception as e:
            print('\n  失败: %s' % e)
            fail += 1

    print('\n完成: 成功 %d, 失败 %d, 目录: %s' % (ok, fail, out_dir))


if __name__ == '__main__':
    main()
